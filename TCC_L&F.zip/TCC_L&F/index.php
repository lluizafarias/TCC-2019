<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/semantic-ui/2.4.1/semantic.min.js"></script>
<link rel="stylesheet" type="text/css" href="css/css_principal.css">
<title>NOME SITE</title>
</head>
<body>
	<div id="bg_menu_inicial">
		<div class="ui grid">
		<div class="row">
    <div class="five wide column"></div>
    <div class="ui six wide column huge header" >
    <p id="nome_inicial">QrList</p>
    <p class="ui medium header" id="slogan">Slogan Slogan Slogan Slogan Slogan</p>
   <div id="botao_pg_inicial">
    <button class="ui black basic button">Black</button>
    <button class="ui black basic button">Black</button>
    </div>
    </div>
    <div class="five wide column"></div>
  </div>
	</div>
	</div>

</body>
