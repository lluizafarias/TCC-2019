<html>
<head>
    <!-- Standard Meta -->
    <meta charset="utf-8">

    <!-- Site Properties -->
    <title>QrList</title>
    <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>
    <body>


        <div class="ui mobile reversed equal width grid">
          <div class="column"></div>
          <div class="column">
            <h1>
                <div class="ui horizontal divider">
                    Criar Conta
                </div>
            </h1>

            <form class="ui large form" method="post" action="../controllers/usuario.php?acao=salvar_usuario">
                <div class="ui stacked segment">

                    <div class="field">
                        <label>Primeiro nome</label>
                        <input name="primeiro_nome" id="primeiro_nome" type="text" placeholder="Ex: Ivo">
                    </div>

                    <div class="field">
                        <label>Sobrenome</label>
                        <input name="sobrenome" id="sobrenome" type="text" placeholder="Ex: Reigel">
                    </div>

                    <div class="field">
                        <label>CPF</label>
                        <input name="cpf" id="cpf" type="text" placeholder="Ex: ***.***.***-**">
                    </div>

                    <div class="field">
                        <label>Telefone</label>
                        <input name="telefone" id="telefone" type="text" placeholder="Ex: (**)****-***">
                    </div>

                    <div class="field">
                        <label>E-mail</label>
                        <input name="email" id="email" type="text" placeholder="Ex: ivo_reigel@gmail.com">
                    </div>

                    <div class="field">
                        <label>Senha</label>
                        <input name="senha" id="senha" placeholder="Ex: ******" type="password">
                    </div>

                    <div class="field">
                        <label>Confirmar Senha</label>
                        <input name="confirmar_senha" id="confirmar_senha" placeholder="Ex: ******" type="password">
                    </div>

                    <button type="submit" class="ui fluid large teal submit button bg_secundario">Cadastrar</button>
                </div>
            </form>
          </div>
          <div class="column"></div>
        </div>


</div>
</div>
</div>
</body>
</html>

