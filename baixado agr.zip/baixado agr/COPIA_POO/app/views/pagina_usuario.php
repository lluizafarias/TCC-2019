<html>
<head>
	<!-- Standard Meta -->
	<meta charset="utf-8">

	<!-- Site Properties -->
	<title>QrList</title>
	<link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<nav>
<div class="ui grey three item inverted menu">
  <a class="active item">
    Home
  </a>
  <a class="item">
    Messages
  </a>
  <a class="item">
    Friends
  </a>
</div>
</nav>

<body>


	<div class="ui width grid">
		<div class="one wide column "></div>
		<div class="fourteen wide column">

			<section class="novaLista">
				<button class="ui primary button direita">+ Nova lista</button>
			</section>
			<div class="ui horizontal divider">
				Mercados cadastrados
			</div>

			<div class="cardMercado">
				<div class="ui card">
					<div class="content">
						<div class="header">Mercado Albino</div>
					</div>
					<div class="content">
						<img class="img_mercado" src="../../imagens/index.jpg">
						<h4 class="ui sub header">informação extra (endereço)</h4>
					</div>
				</div>

			</div>

		</div>
		<div class="one wide column "></div>
	</div>




</body>