<html>
<head>
  <!-- Standard Meta -->
  <meta charset="utf-8">

  <!-- Site Properties -->
  <title>QrList</title>
  <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
  <link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<body>


  <div class="ui mobile reversed equal width grid">
    <div class="column"></div>
    <div class="column">
      <h2>
        <div class="ui horizontal divider">
          Login
        </div>
      </h2>
      <form class="ui large form">
        <div class="ui stacked segment">
          <div class="field">
            <div class="ui left icon input">
              <i class="user icon"></i>
              <input type="text" name="email" placeholder="E-mail">
            </div>
          </div>
          <div class="field">
            <div class="ui left icon input">
              <i class="lock icon"></i>
              <input type="password" name="password" placeholder="Senha">
            </div>
          </div>
          <div class="ui fluid large teal submit button bg_secundario">Entrar</div>
        </div>
      </form>

      <div class="ui message">
        Novo por aqui?  <a href="cadastro.php">Cadastre-se</a>
      </div>
    </div>
    <div class="column"></div>
  </div>



</body>
</html>