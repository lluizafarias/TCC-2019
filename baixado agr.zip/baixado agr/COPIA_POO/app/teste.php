<html>
<head>
	<!-- Standard Meta -->
	<meta charset="utf-8">

	<!-- Site Properties -->
	<title>QrList</title>
	<link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
	<link rel="stylesheet" type="text/css" href="../../css/style.css">
</head>

<body>

	<div class="ui width grid">
		<div class="one wide column aaaa"></div>
		<div class="fourteen wide column">
			<div class="ui horizontal divider">
				adicione produtos a sua lista
			</div>



		</div>
		<div class="one wide column aaaa"></div>
	</div>

</body>