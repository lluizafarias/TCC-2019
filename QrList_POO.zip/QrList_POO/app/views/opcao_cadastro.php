    <html>
    <head>
    	<!-- Standard Meta -->
    	<meta charset="utf-8">
    	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

    	<!-- Site Properties -->
    	<title>QrList</title>
    	<link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
    	<link rel="stylesheet" type="text/css" href="../../css/style.css">
    	<script
    	src="https://code.jquery.com/jquery-3.1.1.min.js"
    	integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
    	crossorigin="anonymous"></script>
    	<script src="../../semantic/dist/semantic.min.js"></script>

    	<body>

    		<div class="ui equal width grid">
    			<div class="column"></div>
    			<div class="column">
    				<a href="cadastro_usuario.php"><button class="ui secondary basic button">Cadastro de Usuario</button></a>
    				<a href="cadastro_mercado.php"><button class="ui secondary basic button">Cadastro de Mercado</button></a>
    			</div>
    			<div class="column"></div>
    		</div>

    	</body>

    	</html>