<?php
    require ('cabecalho.php');
?>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <img src="assets/images/logo.png" class="image">
      <div class="content cor_secundaria">
        Logue-se em sua conta
      </div>
    </h2>
    <form class="ui large form">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="email" placeholder="E-mail">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Senha">
          </div>
        </div>
        <div class="ui fluid large teal submit button bg_secundario">Login</div>
      </div>

      <div class="ui error message"></div>

    </form>

    <div class="ui message">
      Novo por aqui?  <a href="cadastro.php">Cadastre-se</a>
    </div>
  </div>
</div>
</body>
</html>