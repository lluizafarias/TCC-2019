<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

 <!-- Site Properties -->
  <title>QrList</title>
  <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
      <link rel="stylesheet" type="text/css" href="../../css/style.css">
  <script
    src="https://code.jquery.com/jquery-3.1.1.min.js"
    integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
    crossorigin="anonymous"></script>
  <script src="semantic/dist/semantic.min.js"></script>

</head>
<body>
<div class="ui middle aligned center aligned grid">
  <div class="column">
    <h2 class="ui teal image header">
      <img src="assets/images/logo.png" class="image">
      <div class="content cor_secundaria">
        Logue-se em sua conta
      </div>
    </h2>
    <form class="ui large form">
      <div class="ui stacked segment">
        <div class="field">
          <div class="ui left icon input">
            <i class="user icon"></i>
            <input type="text" name="email" placeholder="E-mail">
          </div>
        </div>
        <div class="field">
          <div class="ui left icon input">
            <i class="lock icon"></i>
            <input type="password" name="password" placeholder="Senha">
          </div>
        </div>
        <div class="ui fluid large teal submit button bg_secundario">Login</div>
      </div>

      <div class="ui error message"></div>

    </form>

    <div class="ui message">
      Novo por aqui?  <a href="cadastro.php">Cadastre-se</a>
    </div>
  </div>
</div>
</body>
</html>