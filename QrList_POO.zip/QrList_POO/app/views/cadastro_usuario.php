<?php
require ('cabecalho.php');
?>
<div class="ui grid">
    <div class="row">
        <div class="four wide column"></div>
        <div class="eight wide column">
            <div class="ui middle aligned aligned grid">

                <div class="column">
                    <h2 class="ui teal image header">
                      <img src="../../imagens/QrList_preto.png" class="image">
                        <div class="content cor_secundaria">
                            Criar conta!
                        </div>
                    </h2>
                    <form class="ui large form" method="post" action="../controllers/usuario.php?acao=salvar">
                        <div class="ui stacked segment">

                            <div class="field">
                                <label>Primeiro nome</label>
                                <input name="primeiro_nome" id="primeiro_nome" type="text" placeholder="Ex: Ivo">
                            </div>

                            <div class="field">
                                <label>Sobrenome</label>
                                <input name="sobrenome" id="sobrenome" type="text" placeholder="Ex: Reigel">
                            </div>

                            <div class="field">
                                <label>CPF</label>
                                <input name="cpf" id="cpf" type="text" placeholder="Ex: ***.***.***-**">
                            </div>

                            <div class="field">
                                <label>Telefone</label>
                                <input name="telefone" id="telefone" type="text" placeholder="Ex: (**)****-***">
                            </div>

                            <div class="field">
                                <label>E-mail</label>
                                <input name="email" id="email" type="text" placeholder="Ex: ivoreigel@gmail.com">
                            </div>

                            <div class="field">
                                <label>Senha</label>
                                <input name="senha" id="senha" placeholder="Ex: ******" type="password">
                            </div>

                            <div class="field">
                                <label>Confirmar Senha</label>
                                <input name="confirmar_senha" id="confirmar_senha" placeholder="Ex: ******" type="password">
                            </div>

                            <button type="submit" class="ui fluid large teal submit button bg_secundario" href="http://localhost/QrList_POO/app/views/cadastro_usuario.php?acao=cadastrar" >Cadastrar</button>
                        </div>

                        <div class="ui error message"></div>

                    </form>
                </div>
            </div>
            <div class="four wide column"></div>
        </div>
    </div>
</div>
</body>
</html>

