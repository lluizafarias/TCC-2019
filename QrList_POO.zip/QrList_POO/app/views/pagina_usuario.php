    <html>
    <head>
        <!-- Standard Meta -->
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">

        <!-- Site Properties -->
        <title>QrList</title>
        <link rel="stylesheet" type="text/css" href="../../semantic/dist/semantic.min.css">
        <link rel="stylesheet" type="text/css" href="../../css/style.css">
        <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
        <script src="../../semantic/dist/semantic.min.js"></script>

<body>
    
<!--<div class="ui mobile reversed equal width grid">
  <div class="column ">
    First
  </div>
  <div class="seven column ">
    <div class="ui card">
  <div class="content">
    <div class="header">Project Timeline</div>
  </div>
  <div class="content">
    <h4 class="ui sub header">Activity</h4>
    <div class="ui small feed">
      <div class="event">
        <div class="content">
          <div class="summary">
             <a>Elliot Fu</a> added <a>Jenny Hess</a> to the project
          </div>
        </div>
      </div>
      <div class="event">
        <div class="content">
          <div class="summary">
             <a>Stevie Feliciano</a> was added as an <a>Administrator</a>
          </div>
        </div>
      </div>
      <div class="event">
        <div class="content">
          <div class="summary">
             <a>Helen Troy</a> added two pictures
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="extra content">
    <button class="ui button">Join Project</button>
  </div>
</div>
  </div>
  <div class="column">
    <button class="ui primary basic button novaLista">Primary</button>
  </div>
</div>-->
<div class="ui grid">
    <div class="two wide column bg_primario"></div>
    <div class="fourteen wide column bg_secundario"></div>
</div>
</body>