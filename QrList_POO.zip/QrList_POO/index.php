<?php
require ('app/views/cabecalho.php');
require_once ('app/views/home.php');
?>