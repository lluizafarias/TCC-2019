-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_usu (
desc_tip_usu varchar(20) not null,
cod_tip_usu int(3) not null auto_increment PRIMARY KEY
);

CREATE TABLE tipo_end (
desc_tipo_end varchar(80) not null,
cod_tipo_end int(3) not null auto_increment PRIMARY KEY
);

CREATE TABLE cidade (
nome_cidade varchar(80) not null,
cod_cidade int(3) not null auto_increment PRIMARY KEY,
cod_uf_cod int(3) not null
);

CREATE TABLE bairro (
nome_bairro varchar(80) not null,
cod_bairro int(3) not null auto_increment PRIMARY KEY,
cod_cidade_cod int(3) not null,
FOREIGN KEY(cod_cidade) REFERENCES cidade (cod_cidade)
);

CREATE TABLE mercado (
cnpj int(14) not null auto_increment PRIMARY KEY,
nome_mercado varchar(80) not null,
foto_mercado varchar(300) not null,
cod_end_cod int(3) not null
);

CREATE TABLE lista (
cod_lista int(3) not null auto_increment PRIMARY KEY,
valor_lista varchar(60) not null,
cpf_usuario int(11) not null
);

CREATE TABLE usuario (
primeiro_nome varchar(50) not null,
telefone char(13) not null,
sobrenome varchar(50) not null,
senha varchar(50) not null,
cpf int(11) not null auto_increment PRIMARY KEY,
email varchar(60) not null,
cod_tip_usu int(3) not null,
cod_end_cod int(3) not null,
FOREIGN KEY(cod_tip_usu) REFERENCES tipo_usu (cod_tip_usu)
);

CREATE TABLE item_lista (
cod_produto_cod int(3) not null,
cod_lista_cod int(3) not null,
cod_tem_lista int(3) not null auto_increment PRIMARY KEY,
qtd_item_lista int(10) not null,
FOREIGN KEY(cod_lista) REFERENCES lista (cod_lista)
);

CREATE TABLE produtos (
qtd_item_est int(10) not null,
cod_produto int(3) not null auto_increment PRIMARY KEY,
foto_produto varchar(300) not null,
nome_produto varchar(100) not null,
preco_pord float(5,2) not null,
marca varchar(80) not null,
peso_liq varchar(10) not null,
desc_prod varchar(100) not null
);

CREATE TABLE produtos_mercados (
cod_produto int(3) not null,
cnpj_mercado int(14) not null,
FOREIGN KEY(cod_produto) REFERENCES produtos (cod_produto),
FOREIGN KEY(cnpj) REFERENCES mercado (cnpj)
);

CREATE TABLE endereco (
cod_end int(3) not null auto_increment PRIMARY KEY,
rua varchar(50) not null,
numero int(6) not null,
cod_bairro_cod int(3) not null,
cod_tipo_end int(3) not null,
FOREIGN KEY(cod_bairro) REFERENCES bairro (cod_bairro),
FOREIGN KEY(cod_tipo_end) REFERENCES tipo_end (cod_tipo_end)
);

CREATE TABLE uf (
cod_uf int(3) not null auto_increment PRIMARY KEY,
nome_uf varchar(80) not null
);

ALTER TABLE cidade ADD FOREIGN KEY(cod_uf_cod) REFERENCES uf (cod_uf);
ALTER TABLE mercado ADD FOREIGN KEY(cod_end_cod) REFERENCES endereco (cod_end);
ALTER TABLE lista ADD FOREIGN KEY(cpf) REFERENCES usuario (cpf);
ALTER TABLE usuario ADD FOREIGN KEY(cod_end_cod) REFERENCES endereco (cod_end);
ALTER TABLE item_lista ADD FOREIGN KEY(cod_produto) REFERENCES produtos (cod_produto);
